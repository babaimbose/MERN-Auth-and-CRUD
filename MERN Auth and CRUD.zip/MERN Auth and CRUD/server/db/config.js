const mongoose = require("mongoose");

const connection = async (connString) => {
  try {
    const conn = await mongoose.connect(connString);
    conn ? console.log("Connected...") : console.log("Connection Error");
  } catch (err) {
    console.log(err);
  }
};

module.exports = connection;

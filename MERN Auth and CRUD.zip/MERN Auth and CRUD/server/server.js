const connection = require("./db/config");
const register = require("./controllers/register");
const findUsers = require("./controllers/findUsers");
const findUser = require("./controllers/findUser");
const delUser = require("./controllers/del");
const updateUser = require("./controllers/update");
const login = require("./controllers/login");
const bodyParser = require("body-parser");
const cors = require("cors");
const express = require("express");
const app = express();
const port = 5000;

//invoke the connection
connection("mongodb://127.0.0.1:27017/merntwo");

//json data middlewear......
app.use(express.json());

//cors middlewear......
app.use(cors());

//collect data from form....
app.use(bodyParser.urlencoded({ extended: true }));

//registration api..........
app.post("/", register);

//all users api.........
app.get("/users", findUsers);

//one user api.........
app.get("/user/:id", findUser);

//update api.........
app.put("/update/user/:id", updateUser);

//delte api.........
app.delete("/delete/user/:id", delUser);

//login api
app.post("/login", login);

app.listen(port, console.log(`App running on port ${port}`));

const userModel = require("../model/user");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const privateKey = "privateissecret";

const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (email && password) {
      const user = await userModel.findOne({ email });
      if (user != null) {
        const passCheck = await bcrypt.compare(
          password.toString(),
          user.password
        );
        if (email == user.email && passCheck) {
          const token = jwt.sign(user.toObject(), privateKey, {
            expiresIn: "1h",
          });
          res.send({ message: "Login successful", user, token });
        } else {
          res.send({ message: "Email or password is invalid" });
        }
      } else {
        res.send({ message: "Email or password is invalid" });
      }
    } else {
      res.send({ message: "All the fields are mandatory" });
    }
  } catch (err) {
    console.log(err);
  }
};

module.exports = login;

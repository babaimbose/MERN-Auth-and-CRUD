const userModel = require("../model/user");

const delUser = async (req, res) => {
  try {
    const result = await userModel.findOneAndDelete({ _id: req.params.id });
    res.send({ message: "User deleted successfully..." });
  } catch (err) {
    console.log(err);
  }
};

module.exports = delUser;

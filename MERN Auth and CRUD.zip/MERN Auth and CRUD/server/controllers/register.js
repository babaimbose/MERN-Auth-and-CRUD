const userModel = require("../model/user");
const bcrypt = require("bcrypt");

const register = async (req, res) => {
  try {
    const { name, email, mobile, password } = req.body;
    if (name && email && mobile && password) {
      const user = await userModel.findOne({ email });
      if (user != null) {
        res.send({ message: "User already exists" });
      } else {
        const salt = 10;
        const hashPass = await bcrypt.hash(password, salt);
        const registerUser = await userModel({
          name,
          email,
          mobile,
          password: hashPass,
        });
        registerUser.save();
        res.send(registerUser);
      }
    } else {
      res.send({ message: "All fields are mandatory" });
    }
  } catch (err) {
    console.log(err);
  }
};

module.exports = register;

const userModel = require("../model/user");
const bcrypt = require("bcrypt");

const updateUser = async (req, res) => {
  try {
    const { name, mobile, email, password } = req.body;
    if (name && mobile && email && password) {
      const user = await userModel.findOne({ _id: req.params.id });
      if (user != null) {
        const { name, mobile, email, password } = req.body;
        const salt = 10;
        const hashPass = await bcrypt.hash(password, salt);
        const result = await userModel.updateOne(
          { _id: user._id },
          {
            name,
            mobile,
            email,
            password: hashPass,
          }
        );
        res.send(result);
      } else {
        res.send({ message: "Invalid user" });
      }
    } else {
      res.send({ message: "All fields are mandatory" });
    }
  } catch (err) {
    console.log(err);
  }
};

module.exports = updateUser;

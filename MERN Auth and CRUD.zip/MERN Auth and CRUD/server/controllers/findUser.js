const userModel = require("../model/user");

const findUser = async (req, res) => {
  try {
    const result = await userModel.findOne({ _id: req.params.id });
    res.send(result);
  } catch (err) {
    console.log(err);
  }
};

module.exports = findUser;

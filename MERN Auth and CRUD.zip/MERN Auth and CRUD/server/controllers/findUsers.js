const userModel = require("../model/user");

const findUsers = async (req, res) => {
  try {
    const result = await userModel.find();
    res.send(result);
  } catch (err) {
    console.log(err);
  }
};

module.exports = findUsers;

import Header from "./components/Header";
import Register from "./components/Register";
import Footer from "./components/Footer";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Users from "./components/Users";
import Update from "./components/Update";
import Private from "./components/Private";

function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>
          <Route element={<Private />}>
            <Route path="/users" element={<Users />}></Route>
            <Route path="/update/user/:id" element={<Update />}></Route>
          </Route>
          <Route path="/" element={<Register />}></Route>
          <Route path="/login" element={<Login />}></Route>
        </Routes>
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;

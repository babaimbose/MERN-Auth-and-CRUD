import React from "react";
import { Outlet, Navigate } from "react-router-dom";

function Private() {
  const authToken = sessionStorage.getItem("authToken");
  return <>{authToken ? <Outlet /> : <Navigate to="/login" />}</>;
}

export default Private;

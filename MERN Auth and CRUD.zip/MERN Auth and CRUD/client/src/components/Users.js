import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

function Users() {
  const [state, setState] = useState(() => []);

  useEffect(() => {
    fetchData();
  }, []);

  const params = useParams();

  const fetchData = async () => {
    const data = await fetch("http://localhost:5000/users")
      .then((res) => res.json())
      .then((rec) => setState(() => rec));
  };

  const updateUser = async () => {
    await fetch(`http://localhost:5000/update/user/${params._id}`);
  };

  const deleteUser = async (userid) => {
    await fetch(`http://localhost:5000/delete/user/${userid}`, {
      method: "DELETE",
    });

    fetchData();
  };

  return (
    <>
      <div className="container my-5">
        <h1 className="display-6 my-5">Users Data...</h1>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Contact No</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {state.map((user, i) => {
              return (
                <tr key={i}>
                  <th scope="row">{i + 1}</th>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.mobile}</td>
                  <td>
                    <Link
                      className="btn btn-warning mx-2"
                      to={`/update/user/${user._id}`}
                    >
                      Update
                    </Link>
                    <button
                      className="btn btn-danger"
                      onClick={() => {
                        deleteUser(user._id);
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default Users;

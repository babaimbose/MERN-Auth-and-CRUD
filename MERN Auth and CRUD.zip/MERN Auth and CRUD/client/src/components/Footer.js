import React from "react";

function Footer() {
  return (
    <>
      <p className="text-center fixed-bottom">&copy; 2023</p>
    </>
  );
}

export default Footer;

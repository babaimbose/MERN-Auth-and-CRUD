import React, { useState } from "react";
import { useParams } from "react-router-dom";

function Update() {
  const { id } = useParams();
  const [state, setState] = useState(async () => {
    await fetch(`http://localhost:5000/user/${id}`)
      .then((res) => res.json())
      .then((data) => setState(() => data))
      .catch((err) => console.log(err));
  });

  const handler = (e) => {
    setState(() => {
      return {
        ...state,
        [e.target.name]: e.target.value,
      };
    });
  };

  const submission = async (e) => {
    e.preventDefault();
    const { name, email, mobile, password } = state;
    await fetch(`http://localhost:5000/update/user/${id}`, {
      method: "PUT",
      body: JSON.stringify({ name, email, mobile, password }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    });

    document.querySelector("#message").classList.toggle("d-none");

    setTimeout(() => {
      document.querySelector("#message").classList.toggle("d-none");
    }, 2000);
  };

  return (
    <>
      <div className="container my-5">
        <h1 className="display-6 my-5">Update...</h1>
        <form onSubmit={submission}>
          <div className="mb-3">
            <label className="form-label" htmlFor="name">
              Name
            </label>
            <input
              type="text"
              className="form-control"
              id="name"
              name="name"
              value={state.name}
              onChange={handler}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label " htmlFor="mobile">
              Contact Number
            </label>
            <input
              type="number"
              className="form-control"
              id="mobile"
              name="mobile"
              value={state.mobile}
              onChange={handler}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label" htmlFor="email">
              Email address
            </label>
            <input
              type="email"
              className="form-control"
              id="email"
              name="email"
              value={state.email}
              onChange={handler}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              className="form-control"
              id="password"
              name="password"
              value={state.password}
              onChange={handler}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Update
          </button>
        </form>
        <div
          className="alert alert-success text-center my-5 d-none"
          role="alert"
          id="message"
        >
          <span>Updation successful...</span>
        </div>
      </div>
    </>
  );
}

export default Update;

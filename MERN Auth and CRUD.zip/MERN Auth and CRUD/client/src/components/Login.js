import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();
  const [state, setState] = useState(() => {
    return {
      email: "",
      password: "",
    };
  });

  const [info, setInfo] = useState("");

  const handler = (e) => {
    setState(() => {
      return {
        ...state,
        [e.target.name]: e.target.value,
      };
    });
  };

  const submission = async (e) => {
    const { email, password } = state;
    e.preventDefault();
    await fetch("http://localhost:5000/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((res) => res.json())
      .then((data) => {
        sessionStorage.setItem("name", data.user.name);
        sessionStorage.setItem("authToken", data.token);
      });

    setState(() => {
      return {
        email: "",
        password: "",
      };
    });

    navigate("/users");
  };

  return (
    <>
      <div className="container my-5">
        <h1 className="display-6 my-5">Login...</h1>
        <form onSubmit={submission}>
          <div className="mb-3">
            <label className="form-label" htmlFor="email">
              Email address
            </label>
            <input
              type="email"
              className="form-control"
              id="email"
              name="email"
              value={state.email}
              onChange={handler}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              className="form-control"
              id="password"
              name="password"
              value={state.password}
              onChange={handler}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Login
          </button>
        </form>
        <div className="alert text-center my-5" id="message">
          <span>{"" || info.message}</span>
        </div>
      </div>
    </>
  );
}

export default Login;
